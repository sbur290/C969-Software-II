﻿namespace C969_Project_Assessment_Spencer_Burkett.Forms.Modify_Or_Delete
{
   partial class ModifyAppointmentForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.modifyAppointmentCancelBtn = new System.Windows.Forms.Button();
         this.modifyAppointmentSaveBtn = new System.Windows.Forms.Button();
         this.modifyAppointmentGrpBx = new System.Windows.Forms.GroupBox();
         this.modifyAppointmentEndLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentStartLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentStartDtp = new System.Windows.Forms.DateTimePicker();
         this.modifyAppointmentEndDtp = new System.Windows.Forms.DateTimePicker();
         this.modifyAppointmentTypeCmb = new System.Windows.Forms.ComboBox();
         this.modifyAppointmentURLLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentURLTxtBx = new System.Windows.Forms.TextBox();
         this.modifyAppointmentTypeLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentContactLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentContactTxtBx = new System.Windows.Forms.TextBox();
         this.modifyAppointmentLocationLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentLocationTxtBx = new System.Windows.Forms.TextBox();
         this.modifyAppointmentDescriptionLbl = new System.Windows.Forms.Label();
         this.newAppointmentDescriptionTxtBx = new System.Windows.Forms.TextBox();
         this.modifyAppointmentTitleLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentTitleTxtBx = new System.Windows.Forms.TextBox();
         this.modifyAppointmentCustomerNameLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentUserIDCmb = new System.Windows.Forms.ComboBox();
         this.modifyAppointmentCustomerIDLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentUsernameLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentCustomerIDCmb = new System.Windows.Forms.ComboBox();
         this.modifyAppointmentUserIDLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentIDLbl = new System.Windows.Forms.Label();
         this.modifyAppointmentIDTxtBx = new System.Windows.Forms.TextBox();
         this.modifyAppointmentGrpBx.SuspendLayout();
         this.SuspendLayout();
         // 
         // modifyAppointmentCancelBtn
         // 
         this.modifyAppointmentCancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this.modifyAppointmentCancelBtn.Location = new System.Drawing.Point(334, 306);
         this.modifyAppointmentCancelBtn.Name = "modifyAppointmentCancelBtn";
         this.modifyAppointmentCancelBtn.Size = new System.Drawing.Size(91, 23);
         this.modifyAppointmentCancelBtn.TabIndex = 33;
         this.modifyAppointmentCancelBtn.Text = "Cancel";
         this.modifyAppointmentCancelBtn.UseVisualStyleBackColor = true;
         this.modifyAppointmentCancelBtn.Click += new System.EventHandler(this.modifyAppointmentCancelBtn_Click);
         // 
         // modifyAppointmentSaveBtn
         // 
         this.modifyAppointmentSaveBtn.Location = new System.Drawing.Point(18, 305);
         this.modifyAppointmentSaveBtn.Name = "modifyAppointmentSaveBtn";
         this.modifyAppointmentSaveBtn.Size = new System.Drawing.Size(91, 23);
         this.modifyAppointmentSaveBtn.TabIndex = 32;
         this.modifyAppointmentSaveBtn.Text = "Save";
         this.modifyAppointmentSaveBtn.UseVisualStyleBackColor = true;
         this.modifyAppointmentSaveBtn.Click += new System.EventHandler(this.modifyAppointmentSaveBtn_Click);
         // 
         // modifyAppointmentGrpBx
         // 
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentEndLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentStartLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentStartDtp);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentEndDtp);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentTypeCmb);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentURLLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentURLTxtBx);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentTypeLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentContactLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentContactTxtBx);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentLocationLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentLocationTxtBx);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentDescriptionLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.newAppointmentDescriptionTxtBx);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentTitleLbl);
         this.modifyAppointmentGrpBx.Controls.Add(this.modifyAppointmentTitleTxtBx);
         this.modifyAppointmentGrpBx.Location = new System.Drawing.Point(17, 72);
         this.modifyAppointmentGrpBx.Name = "modifyAppointmentGrpBx";
         this.modifyAppointmentGrpBx.Size = new System.Drawing.Size(407, 228);
         this.modifyAppointmentGrpBx.TabIndex = 31;
         this.modifyAppointmentGrpBx.TabStop = false;
         this.modifyAppointmentGrpBx.Text = "Appointment Details";
         // 
         // modifyAppointmentEndLbl
         // 
         this.modifyAppointmentEndLbl.AutoSize = true;
         this.modifyAppointmentEndLbl.Location = new System.Drawing.Point(72, 200);
         this.modifyAppointmentEndLbl.Name = "modifyAppointmentEndLbl";
         this.modifyAppointmentEndLbl.Size = new System.Drawing.Size(55, 13);
         this.modifyAppointmentEndLbl.TabIndex = 17;
         this.modifyAppointmentEndLbl.Text = "End Time:";
         // 
         // modifyAppointmentStartLbl
         // 
         this.modifyAppointmentStartLbl.AutoSize = true;
         this.modifyAppointmentStartLbl.Location = new System.Drawing.Point(72, 173);
         this.modifyAppointmentStartLbl.Name = "modifyAppointmentStartLbl";
         this.modifyAppointmentStartLbl.Size = new System.Drawing.Size(58, 13);
         this.modifyAppointmentStartLbl.TabIndex = 16;
         this.modifyAppointmentStartLbl.Text = "Start Time:";
         // 
         // modifyAppointmentStartDtp
         // 
         this.modifyAppointmentStartDtp.CustomFormat = "ddd dd MMM yyyy HH:mm:ss tt";
         this.modifyAppointmentStartDtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
         this.modifyAppointmentStartDtp.Location = new System.Drawing.Point(138, 170);
         this.modifyAppointmentStartDtp.Name = "modifyAppointmentStartDtp";
         this.modifyAppointmentStartDtp.ShowUpDown = true;
         this.modifyAppointmentStartDtp.Size = new System.Drawing.Size(200, 20);
         this.modifyAppointmentStartDtp.TabIndex = 8;
         this.modifyAppointmentStartDtp.Value = new System.DateTime(2023, 11, 30, 9, 0, 0, 0);
         // 
         // modifyAppointmentEndDtp
         // 
         this.modifyAppointmentEndDtp.CustomFormat = "ddd dd MMM yyyy HH:mm:ss tt";
         this.modifyAppointmentEndDtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
         this.modifyAppointmentEndDtp.Location = new System.Drawing.Point(138, 196);
         this.modifyAppointmentEndDtp.Name = "modifyAppointmentEndDtp";
         this.modifyAppointmentEndDtp.ShowUpDown = true;
         this.modifyAppointmentEndDtp.Size = new System.Drawing.Size(200, 20);
         this.modifyAppointmentEndDtp.TabIndex = 9;
         this.modifyAppointmentEndDtp.Value = new System.DateTime(2023, 12, 1, 9, 30, 0, 0);
         // 
         // modifyAppointmentTypeCmb
         // 
         this.modifyAppointmentTypeCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.modifyAppointmentTypeCmb.FormattingEnabled = true;
         this.modifyAppointmentTypeCmb.Location = new System.Drawing.Point(46, 139);
         this.modifyAppointmentTypeCmb.Name = "modifyAppointmentTypeCmb";
         this.modifyAppointmentTypeCmb.Size = new System.Drawing.Size(121, 21);
         this.modifyAppointmentTypeCmb.TabIndex = 6;
         // 
         // modifyAppointmentURLLbl
         // 
         this.modifyAppointmentURLLbl.AutoSize = true;
         this.modifyAppointmentURLLbl.Location = new System.Drawing.Point(173, 142);
         this.modifyAppointmentURLLbl.Name = "modifyAppointmentURLLbl";
         this.modifyAppointmentURLLbl.Size = new System.Drawing.Size(32, 13);
         this.modifyAppointmentURLLbl.TabIndex = 11;
         this.modifyAppointmentURLLbl.Text = "URL:";
         // 
         // modifyAppointmentURLTxtBx
         // 
         this.modifyAppointmentURLTxtBx.Location = new System.Drawing.Point(211, 139);
         this.modifyAppointmentURLTxtBx.Name = "modifyAppointmentURLTxtBx";
         this.modifyAppointmentURLTxtBx.Size = new System.Drawing.Size(174, 20);
         this.modifyAppointmentURLTxtBx.TabIndex = 7;
         // 
         // modifyAppointmentTypeLbl
         // 
         this.modifyAppointmentTypeLbl.AutoSize = true;
         this.modifyAppointmentTypeLbl.Location = new System.Drawing.Point(6, 142);
         this.modifyAppointmentTypeLbl.Name = "modifyAppointmentTypeLbl";
         this.modifyAppointmentTypeLbl.Size = new System.Drawing.Size(34, 13);
         this.modifyAppointmentTypeLbl.TabIndex = 9;
         this.modifyAppointmentTypeLbl.Text = "Type:";
         // 
         // modifyAppointmentContactLbl
         // 
         this.modifyAppointmentContactLbl.AutoSize = true;
         this.modifyAppointmentContactLbl.Location = new System.Drawing.Point(6, 116);
         this.modifyAppointmentContactLbl.Name = "modifyAppointmentContactLbl";
         this.modifyAppointmentContactLbl.Size = new System.Drawing.Size(47, 13);
         this.modifyAppointmentContactLbl.TabIndex = 7;
         this.modifyAppointmentContactLbl.Text = "Contact:";
         // 
         // modifyAppointmentContactTxtBx
         // 
         this.modifyAppointmentContactTxtBx.Location = new System.Drawing.Point(59, 113);
         this.modifyAppointmentContactTxtBx.Name = "modifyAppointmentContactTxtBx";
         this.modifyAppointmentContactTxtBx.Size = new System.Drawing.Size(326, 20);
         this.modifyAppointmentContactTxtBx.TabIndex = 5;
         // 
         // modifyAppointmentLocationLbl
         // 
         this.modifyAppointmentLocationLbl.AutoSize = true;
         this.modifyAppointmentLocationLbl.Location = new System.Drawing.Point(6, 90);
         this.modifyAppointmentLocationLbl.Name = "modifyAppointmentLocationLbl";
         this.modifyAppointmentLocationLbl.Size = new System.Drawing.Size(51, 13);
         this.modifyAppointmentLocationLbl.TabIndex = 5;
         this.modifyAppointmentLocationLbl.Text = "Location:";
         // 
         // modifyAppointmentLocationTxtBx
         // 
         this.modifyAppointmentLocationTxtBx.Location = new System.Drawing.Point(63, 87);
         this.modifyAppointmentLocationTxtBx.Name = "modifyAppointmentLocationTxtBx";
         this.modifyAppointmentLocationTxtBx.Size = new System.Drawing.Size(322, 20);
         this.modifyAppointmentLocationTxtBx.TabIndex = 4;
         // 
         // modifyAppointmentDescriptionLbl
         // 
         this.modifyAppointmentDescriptionLbl.AutoSize = true;
         this.modifyAppointmentDescriptionLbl.Location = new System.Drawing.Point(6, 64);
         this.modifyAppointmentDescriptionLbl.Name = "modifyAppointmentDescriptionLbl";
         this.modifyAppointmentDescriptionLbl.Size = new System.Drawing.Size(63, 13);
         this.modifyAppointmentDescriptionLbl.TabIndex = 3;
         this.modifyAppointmentDescriptionLbl.Text = "Description:";
         // 
         // newAppointmentDescriptionTxtBx
         // 
         this.newAppointmentDescriptionTxtBx.Location = new System.Drawing.Point(75, 61);
         this.newAppointmentDescriptionTxtBx.Name = "newAppointmentDescriptionTxtBx";
         this.newAppointmentDescriptionTxtBx.Size = new System.Drawing.Size(310, 20);
         this.newAppointmentDescriptionTxtBx.TabIndex = 3;
         // 
         // modifyAppointmentTitleLbl
         // 
         this.modifyAppointmentTitleLbl.AutoSize = true;
         this.modifyAppointmentTitleLbl.Location = new System.Drawing.Point(6, 38);
         this.modifyAppointmentTitleLbl.Name = "modifyAppointmentTitleLbl";
         this.modifyAppointmentTitleLbl.Size = new System.Drawing.Size(30, 13);
         this.modifyAppointmentTitleLbl.TabIndex = 1;
         this.modifyAppointmentTitleLbl.Text = "Title:";
         // 
         // modifyAppointmentTitleTxtBx
         // 
         this.modifyAppointmentTitleTxtBx.Location = new System.Drawing.Point(42, 35);
         this.modifyAppointmentTitleTxtBx.Name = "modifyAppointmentTitleTxtBx";
         this.modifyAppointmentTitleTxtBx.Size = new System.Drawing.Size(343, 20);
         this.modifyAppointmentTitleTxtBx.TabIndex = 2;
         // 
         // modifyAppointmentCustomerNameLbl
         // 
         this.modifyAppointmentCustomerNameLbl.AutoSize = true;
         this.modifyAppointmentCustomerNameLbl.Location = new System.Drawing.Point(96, 21);
         this.modifyAppointmentCustomerNameLbl.Name = "modifyAppointmentCustomerNameLbl";
         this.modifyAppointmentCustomerNameLbl.Size = new System.Drawing.Size(85, 13);
         this.modifyAppointmentCustomerNameLbl.TabIndex = 30;
         this.modifyAppointmentCustomerNameLbl.Text = "Customer Name:";
         // 
         // modifyAppointmentUserIDCmb
         // 
         this.modifyAppointmentUserIDCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.modifyAppointmentUserIDCmb.FormattingEnabled = true;
         this.modifyAppointmentUserIDCmb.Location = new System.Drawing.Point(332, 45);
         this.modifyAppointmentUserIDCmb.Name = "modifyAppointmentUserIDCmb";
         this.modifyAppointmentUserIDCmb.Size = new System.Drawing.Size(92, 21);
         this.modifyAppointmentUserIDCmb.TabIndex = 25;
         // 
         // modifyAppointmentCustomerIDLbl
         // 
         this.modifyAppointmentCustomerIDLbl.AutoSize = true;
         this.modifyAppointmentCustomerIDLbl.Location = new System.Drawing.Point(281, 21);
         this.modifyAppointmentCustomerIDLbl.Name = "modifyAppointmentCustomerIDLbl";
         this.modifyAppointmentCustomerIDLbl.Size = new System.Drawing.Size(68, 13);
         this.modifyAppointmentCustomerIDLbl.TabIndex = 29;
         this.modifyAppointmentCustomerIDLbl.Text = "Customer ID:";
         // 
         // modifyAppointmentUsernameLbl
         // 
         this.modifyAppointmentUsernameLbl.AutoSize = true;
         this.modifyAppointmentUsernameLbl.Location = new System.Drawing.Point(96, 48);
         this.modifyAppointmentUsernameLbl.Name = "modifyAppointmentUsernameLbl";
         this.modifyAppointmentUsernameLbl.Size = new System.Drawing.Size(58, 13);
         this.modifyAppointmentUsernameLbl.TabIndex = 28;
         this.modifyAppointmentUsernameLbl.Text = "Username:";
         // 
         // modifyAppointmentCustomerIDCmb
         // 
         this.modifyAppointmentCustomerIDCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.modifyAppointmentCustomerIDCmb.FormattingEnabled = true;
         this.modifyAppointmentCustomerIDCmb.Location = new System.Drawing.Point(355, 18);
         this.modifyAppointmentCustomerIDCmb.Name = "modifyAppointmentCustomerIDCmb";
         this.modifyAppointmentCustomerIDCmb.Size = new System.Drawing.Size(69, 21);
         this.modifyAppointmentCustomerIDCmb.TabIndex = 23;
         // 
         // modifyAppointmentUserIDLbl
         // 
         this.modifyAppointmentUserIDLbl.AutoSize = true;
         this.modifyAppointmentUserIDLbl.Location = new System.Drawing.Point(281, 48);
         this.modifyAppointmentUserIDLbl.Name = "modifyAppointmentUserIDLbl";
         this.modifyAppointmentUserIDLbl.Size = new System.Drawing.Size(46, 13);
         this.modifyAppointmentUserIDLbl.TabIndex = 27;
         this.modifyAppointmentUserIDLbl.Text = "User ID:";
         // 
         // modifyAppointmentIDLbl
         // 
         this.modifyAppointmentIDLbl.AutoSize = true;
         this.modifyAppointmentIDLbl.Location = new System.Drawing.Point(17, 21);
         this.modifyAppointmentIDLbl.Name = "modifyAppointmentIDLbl";
         this.modifyAppointmentIDLbl.Size = new System.Drawing.Size(21, 13);
         this.modifyAppointmentIDLbl.TabIndex = 24;
         this.modifyAppointmentIDLbl.Text = "ID:";
         // 
         // modifyAppointmentIDTxtBx
         // 
         this.modifyAppointmentIDTxtBx.Location = new System.Drawing.Point(40, 18);
         this.modifyAppointmentIDTxtBx.Name = "modifyAppointmentIDTxtBx";
         this.modifyAppointmentIDTxtBx.ReadOnly = true;
         this.modifyAppointmentIDTxtBx.Size = new System.Drawing.Size(46, 20);
         this.modifyAppointmentIDTxtBx.TabIndex = 34;
         // 
         // ModifyAppointmentForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(443, 346);
         this.Controls.Add(this.modifyAppointmentIDTxtBx);
         this.Controls.Add(this.modifyAppointmentCancelBtn);
         this.Controls.Add(this.modifyAppointmentSaveBtn);
         this.Controls.Add(this.modifyAppointmentGrpBx);
         this.Controls.Add(this.modifyAppointmentCustomerNameLbl);
         this.Controls.Add(this.modifyAppointmentUserIDCmb);
         this.Controls.Add(this.modifyAppointmentCustomerIDLbl);
         this.Controls.Add(this.modifyAppointmentUsernameLbl);
         this.Controls.Add(this.modifyAppointmentCustomerIDCmb);
         this.Controls.Add(this.modifyAppointmentUserIDLbl);
         this.Controls.Add(this.modifyAppointmentIDLbl);
         this.Name = "ModifyAppointmentForm";
         this.Text = "Modify Appointment";
         this.Load += new System.EventHandler(this.ModifyAppointmentForm_Load);
         this.modifyAppointmentGrpBx.ResumeLayout(false);
         this.modifyAppointmentGrpBx.PerformLayout();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Button modifyAppointmentCancelBtn;
      private System.Windows.Forms.Button modifyAppointmentSaveBtn;
      private System.Windows.Forms.GroupBox modifyAppointmentGrpBx;
      private System.Windows.Forms.Label modifyAppointmentEndLbl;
      private System.Windows.Forms.Label modifyAppointmentStartLbl;
      private System.Windows.Forms.DateTimePicker modifyAppointmentStartDtp;
      private System.Windows.Forms.DateTimePicker modifyAppointmentEndDtp;
      private System.Windows.Forms.ComboBox modifyAppointmentTypeCmb;
      private System.Windows.Forms.Label modifyAppointmentURLLbl;
      private System.Windows.Forms.TextBox modifyAppointmentURLTxtBx;
      private System.Windows.Forms.Label modifyAppointmentTypeLbl;
      private System.Windows.Forms.Label modifyAppointmentContactLbl;
      private System.Windows.Forms.TextBox modifyAppointmentContactTxtBx;
      private System.Windows.Forms.Label modifyAppointmentLocationLbl;
      private System.Windows.Forms.TextBox modifyAppointmentLocationTxtBx;
      private System.Windows.Forms.Label modifyAppointmentDescriptionLbl;
      private System.Windows.Forms.TextBox newAppointmentDescriptionTxtBx;
      private System.Windows.Forms.Label modifyAppointmentTitleLbl;
      private System.Windows.Forms.TextBox modifyAppointmentTitleTxtBx;
      private System.Windows.Forms.Label modifyAppointmentCustomerNameLbl;
      private System.Windows.Forms.ComboBox modifyAppointmentUserIDCmb;
      private System.Windows.Forms.Label modifyAppointmentCustomerIDLbl;
      private System.Windows.Forms.Label modifyAppointmentUsernameLbl;
      private System.Windows.Forms.ComboBox modifyAppointmentCustomerIDCmb;
      private System.Windows.Forms.Label modifyAppointmentUserIDLbl;
      private System.Windows.Forms.Label modifyAppointmentIDLbl;
      private System.Windows.Forms.TextBox modifyAppointmentIDTxtBx;
   }
}